import { useEffect, useState } from 'react';

export default function MemoryViewer() {
  const [memories, setMemories] = useState([]);
  const [filter, setFilter] = useState('');

  useEffect(() => {
    fetch('https://usblvdhbvwlxvegdwoaa.supabase.co/rest/v1/memories?select=*', {
      headers: {
        apikey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVzYmx2ZGhidndseHZlZ2R3b2FhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTE5MzU1MDAsImV4cCI6MjA2NzUxMTUwMH0.3k9XQH5pSi4-RT53D8feizcxsZJengNN-Sj_A1vWjrQ',
        Authorization: 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVzYmx2ZGhidndseHZlZ2R3b2FhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTE5MzU1MDAsImV4cCI6MjA2NzUxMTUwMH0.3k9XQH5pSi4-RT53D8feizcxsZJengNN-Sj_A1vWjrQ'
      },
    })
      .then(res => res.json())
      .then(setMemories);
  }, []);

  const filtered = memories.filter(m =>
    m.input.toLowerCase().includes(filter.toLowerCase()) ||
    m.output.toLowerCase().includes(filter.toLowerCase())
  );

  return (
    <div className="p-4 space-y-4">
      <input
        className="w-full p-2 border rounded"
        placeholder="Search memory..."
        value={filter}
        onChange={e => setFilter(e.target.value)}
      />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.map(m => (
          <div key={m.id} className="p-4 border rounded shadow">
            <p className="text-sm text-gray-500">{new Date(m.timestamp).toLocaleString()}</p>
            <p className="font-semibold">🧠 {m.input}</p>
            <p className="text-blue-700">💬 {m.output}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
